// web app's Firebase configuration

const firebaseConfig = {
  apiKey: "AIzaSyAClXCmZ7AIclopuDElaVpU78os3OxEdII",
  authDomain: "project-9356b.firebaseapp.com",
  databaseURL: "https://project-9356b-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "project-9356b",
  storageBucket: "project-9356b.appspot.com",
  messagingSenderId: "34734787169",
  appId: "1:34734787169:web:32a876355db12fa717f820",
  measurementId: "G-GH2FZ0KBW5"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Firebase services
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();