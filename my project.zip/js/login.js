(function() {
    // Log In Function
    function logIn() {
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        auth.signInWithEmailAndPassword(email, password)
            .then(userCredential => {
                const user = userCredential.user;
                if (user.emailVerified) {
                    console.log('User logged in:', user);
                    alert('Login Successful!');
                    window.location.href = "chat.html"; // Redirect to chat page
                } else {
                    auth.signOut();
                    alert('Please verify your email before logging in.');
                }
            })
            .catch(error => {
                console.error('Error logging in:', error);
                alert('Error: ' + error.message);
            });
    }

    // Attach logIn function to window for HTML onclick attribute
    window.logIn = logIn;
})();