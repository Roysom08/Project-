const auth = firebase.auth();
const db = firebase.firestore();

// Load Profile Data
const loadProfile = () => {
    const user = auth.currentUser;
    if (user) {
        db.collection('users').doc(user.uid).get()
            .then(doc => {
                if (doc.exists) {
                    document.getElementById('profile-email').textContent = `Email: ${doc.data().email}`;
                    document.getElementById('profile-username').textContent = `Username: ${doc.data().username}`;
                }
            })
            .catch(error => {
                console.error('Error loading profile:', error);
                alert('Error: ' + error.message);
            });
    } else {
        window.location.href = "login.html";
    }
};

// Edit Profile Function
const editProfile = () => {
    const newUsername = prompt('Enter new username:');
    const user = auth.currentUser;

    if (newUsername) {
        db.collection('users').doc(user.uid).update({
            username: newUsername
        })
        .then(() => {
            alert('Profile updated!');
            loadProfile(); // Reload profile data
        })
        .catch(error => {
            console.error('Error updating profile:', error);
            alert('Error: ' + error.message);
        });
    }
};

// Load profile data when the page loads
window.onload = loadProfile;

