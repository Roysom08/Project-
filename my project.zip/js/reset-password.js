(function() {
    // Reset Password Function
    function resetPassword() {
        const email = document.getElementById('reset-email').value;

        auth.sendPasswordResetEmail(email)
            .then(() => {
                console.log('Password reset email sent');
                alert('Password reset email sent! Please check your inbox.');
            })
            .catch(error => {
                console.error('Error sending password reset email:', error);
                alert('Error: ' + error.message);
            });
    }

    // Attach resetPassword function to window for HTML onclick attribute
    window.resetPassword = resetPassword;
})();

