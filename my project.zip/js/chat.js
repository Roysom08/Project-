(function() {
    let selectedUser = null;
    const usersList = document.getElementById('users');
    const chatWindow = document.getElementById('chatWindow');
    const messageInput = document.getElementById('messageInput');
    const sendMessageButton = document.getElementById('sendMessage');

    // Function to display users
    function displayUsers() {
        db.collection('users').get().then(querySnapshot => {
            if (querySnapshot.empty) {
                console.log('No users found.');
                return;
            }
            usersList.innerHTML = '';
            querySnapshot.forEach(doc => {
                const userData = doc.data();
                console.log('User data:', userData); // Debugging line
                const listItem = document.createElement('li');
                listItem.textContent = userData.username;
                listItem.dataset.userId = doc.id;
                listItem.addEventListener('click', () => selectUser(doc.id, userData.username));
                usersList.appendChild(listItem);
            });
        }).catch(error => {
            console.error('Error fetching users:', error);
        });
    }

    // Function to select a user and load chat history
    function selectUser(userId, username) {
        selectedUser = userId;
        chatWindow.innerHTML = ''; // Clear chat window
        loadChatHistory(userId);
    }

    // Function to load chat history
    function loadChatHistory(userId) {
        const currentUserId = firebase.auth().currentUser.uid;
        const chatRef = db.collection('chats').doc(currentUserId).collection(userId);

        chatRef.orderBy('timestamp').onSnapshot(snapshot => {
            chatWindow.innerHTML = '';
            snapshot.forEach(doc => {
                const messageData = doc.data();
                console.log('Message data:', messageData); // Debugging line
                const messageElement = document.createElement('div');
                messageElement.textContent = `${messageData.sender}: ${messageData.text}`;
                chatWindow.appendChild(messageElement);
            });
        });
    }

    // Function to send a message
    function sendMessage() {
        if (!selectedUser) {
            alert('Select a user to chat with.');
            return;
        }

        const messageText = messageInput.value;
        if (messageText.trim() === '') {
            alert('Message cannot be empty.');
            return;
        }

        const currentUserId = firebase.auth().currentUser.uid;
        const chatRef1 = db.collection('chats').doc(currentUserId).collection(selectedUser);
        const chatRef2 = db.collection('chats').doc(selectedUser).collection(currentUserId);

        const message = {
            sender: 'You',
            text: messageText,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        };

        chatRef1.add(message);
        chatRef2.add({ ...message, sender: 'Other User' });

        messageInput.value = '';
    }

    // Event listeners
    sendMessageButton.addEventListener('click', sendMessage);

    // Initialize
    displayUsers();
})();