(function() {
    // Sign Up Function
    function signUp() {
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;
        const username = document.getElementById('signup-username').value;

        auth.createUserWithEmailAndPassword(email, password)
            .then(userCredential => {
                const user = userCredential.user;
                return user.sendEmailVerification().then(() => {
                    return db.collection('users').doc(user.uid).set({
                        email: email,
                        username: username
                    });
                });
            })
            .then(() => {
                console.log('User signed up and verification email sent');
                alert('Sign Up Successful! Please verify your email before logging in.');
                window.location.href = "login.html"; // Redirect to login page
            })
            .catch(error => {
                console.error('Error signing up:', error);
                alert('Error: ' + error.message);
            });
    }

    // Attach signUp function to window for HTML onclick attribute
    window.signUp = signUp;
})();